package com.example.foodtruck;

import com.example.foodtruck.Model.FoodTruck;
import com.example.foodtruck.Repository.FoodTruckRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

@SpringBootTest
class FoodTruckApplicationTests {

	@Test
	void contextLoads() {
	}
	@Autowired
	private FoodTruckRepository foodTruckRepository;

	@Test
	public void testFindFoodTruckById() {
		// Given
		FoodTruck foodTruck = new FoodTruck();
		// Set foodTruck properties as needed for your test

		// Save foodTruck to the database
		FoodTruck savedFoodTruck = foodTruckRepository.save(foodTruck);

		// When
		FoodTruck foundFoodTruck = foodTruckRepository.findFoodTruckById(savedFoodTruck.getId());

		// Then
		Assertions.assertNotNull(foundFoodTruck);
		Assertions.assertEquals(savedFoodTruck.getId(), foundFoodTruck.getId());
		// Add more assertions based on your requirements
	}

	@Test
	public void testCheck() {
		// Implement test for the check() method
		List<FoodTruck> foodTrucks = foodTruckRepository.check();
		// Add assertions based on your requirements
	}

	@Test
	public void testFindFoodTruckByRating() {
		// Implement test for the findFoodTruckByRating() method
		List<FoodTruck> foodTrucks = foodTruckRepository.findFoodTruckByRating(3.0, 4.0);
		// Add assertions based on your requirements
	}

	@Test
	public void testFindFByDay() {
		// Implement test for the findFByDay() method
		List<FoodTruck> foodTrucks = foodTruckRepository.findFByDay(4.0, 10);
		// Add assertions based on your requirements
	}

	@Test
	public void testFindFoodTruckByName() {
		// Implement test for the findFoodTruckByName() method
		FoodTruck foundFoodTruck = foodTruckRepository.findFoodTruckByName("Example Food Truck");
		// Add assertions based on your requirements
	}

	@Test
	public void testGetAllFoodTruckNotChecked() {
		// Implement test for the getAllFoodTruckNotChecked() method

		List<FoodTruck> notCheckedFoodTrucks = foodTruckRepository.getAllFoodTruckNotChecked();
		// Add assertions based on your requirements
	}

}