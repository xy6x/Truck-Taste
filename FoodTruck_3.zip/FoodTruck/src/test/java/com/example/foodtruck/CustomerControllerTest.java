package com.example.foodtruck;

import com.example.foodtruck.Controller.CustomerController;
import com.example.foodtruck.DTO.CustomerDTO;
import com.example.foodtruck.Model.User;
import com.example.foodtruck.Service.CustomerService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import static org.springframework.mock.http.server.reactive.MockServerHttpRequest.put;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


@WebMvcTest(value = CustomerController.class, excludeAutoConfiguration = {SecurityAutoConfiguration.class})
//@ExtendWith(SpringExtension.class)
public class CustomerControllerTest {
        @MockBean
        CustomerService customerService;

        @Autowired
        MockMvc mockMvc;
        CustomerDTO customerDTO;

        User user;

        @BeforeEach
        void setUp() {
            user=new User(1,"roaa","1234","roaa@gmail.com","0530956429","ADMIN",null,null);
            customerDTO=new CustomerDTO("ali","1234","ali@gmail.com","0504572751","CUSTOMER");

        }
        @Test
        public void testAddCustomer() throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mockMvc.perform(MockMvcRequestBuilders.post("/api/v1/user/add")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(mapper.writeValueAsString(customerDTO)))
                    .andExpect(status().isOk());
        }
        @Test
        public void testDeleteCustomer() throws Exception {
            mockMvc.perform(delete("/api/v1/user/delete/{id}",user.getId()))
                    .andExpect(status().isOk());
        }
        @Test
        public void testCheck() throws Exception {
            mockMvc.perform(get("/api/v1/user/check"))
                    .andExpect(status().isOk());
        }
            @Test
    public void testFoodTruckAcceptCheck() throws Exception {
        mockMvc.perform(get("/api/v1/user/foodTruckAcceptCheck/{admin_id}/{food_id}",user.getId(),user.getFoodTruck().getId()))
                .andExpect(status().isOk());
    }
    @Test
    public void testFoodReq() throws Exception {
        mockMvc.perform(get("/api/v1/user/food/{number}",user.getFoodTruck().getRequests()))
                .andExpect(status().isOk());
    }
@Test
public void testUpdateCustomer() throws Exception {
    ObjectMapper mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mockMvc.perform(MockMvcRequestBuilders.put("/api/v1/user/put")
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(mapper.writeValueAsString(customerDTO)))
            .andExpect(status().isOk());
}
        @Test
        public void testUpdateCustomer() throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            mapper.registerModule(new JavaTimeModule());
            mockMvc.perform(put("/api/v1/user/put/{id}",user.getId())
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(mapper.writeValueAsString(customerDTO)))
                            .andExpect(status().isOk());
        }
}
