package com.example.foodtruck;

public @interface ExtendWith {
}
