package com.example.foodtruck.Controller;

import com.example.foodtruck.DTO.ProfileDTO;
import com.example.foodtruck.Model.Customer;
import com.example.foodtruck.Model.User;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/profile")
public class ProfileController {
    private final com.example.foodtruck.Service.ProfileService profileService;

    @GetMapping("/get")
    public ResponseEntity GetAllProfile(){
        return ResponseEntity.status(HttpStatus.OK).body(profileService.getProfile());
    }
    @PostMapping("/add")
    public  ResponseEntity AddProfile(@AuthenticationPrincipal Customer auth, @RequestBody @Valid ProfileDTO profileDTO){
        profileService.addProfile(profileDTO,auth.getId());
        return ResponseEntity.status(HttpStatus.OK).body("added Profile");
    }
    @PutMapping("/put/{id}")
    public ResponseEntity UpdateProfile(@AuthenticationPrincipal User auth,@PathVariable Integer id,@RequestBody @Valid ProfileDTO profileDTO){
        profileService.updateProfile(id, profileDTO,auth.getCustomer().getId());
        return ResponseEntity.status(HttpStatus.OK).body("update Profile");
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteProfile(@PathVariable Integer id){
        profileService.deleteProfile(id);
        return ResponseEntity.status(HttpStatus.OK).body("delete Profile");
    }
    @GetMapping("/getById/{id}")
    public ResponseEntity getById(@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(profileService.findUserById(id));
    }
}
