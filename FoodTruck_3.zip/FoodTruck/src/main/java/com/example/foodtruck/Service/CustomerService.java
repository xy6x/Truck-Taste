package com.example.foodtruck.Service;

import com.example.foodtruck.ApiException.ApiException;
import com.example.foodtruck.DTO.CustomerDTO;
import com.example.foodtruck.Model.Customer;
import com.example.foodtruck.Model.FoodTruck;
import com.example.foodtruck.Model.User;
import com.example.foodtruck.Repository.CustomerRepository;
import com.example.foodtruck.Repository.FoodTruckRepository;
import com.example.foodtruck.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CustomerService {
    private final CustomerRepository customerRepository;
    private final FoodTruckRepository foodTruckRepository;
    private final UserRepository userRepository;

    public List<Customer> getAll() {
        return customerRepository.findAll();
    }

    public void addCustomer(CustomerDTO customerDTO) {

        User user = new User(null, customerDTO.getUserName(), customerDTO.getPassword(), customerDTO.getEmail(), customerDTO.getPhone(), customerDTO.getRole(), null, null);
        user.setRole("CUSTOMER");
        String hash = new BCryptPasswordEncoder().encode(user.getPassword());
        user.setPassword(hash);
        userRepository.save(user);
        Customer customer = new Customer(user.getId(), null, null, null, null, user);
        customerRepository.save(customer);
    }

    public void updateCustomer(Integer id, CustomerDTO customerDTO) {
        Customer oldCustomer = customerRepository.findCustomerById(id);
        if (oldCustomer == null) {
            throw new ApiException("Customer id not found");
        }
        if (oldCustomer.getUser().getEmail() != customerDTO.getEmail()){
            throw new ApiException("the user not same");
    }
        String hash = new BCryptPasswordEncoder().encode(oldCustomer.getUser().getPassword());
        oldCustomer.getUser().setPassword(hash);
    customerRepository.save(oldCustomer);
}
    public void deleteCustomer(Integer auth){
        Customer customer = customerRepository.findCustomerById(auth);
        if (customer == null) {
            throw new ApiException("the id nt found");
        }
        customerRepository.delete(customer);
    }
    public List<FoodTruck> checkIfFoodTruckAvailable(){
       List<FoodTruck> foodTruck =foodTruckRepository.check();
        if (foodTruck == null) {
            throw new ApiException("the id nt found");
        }
        return foodTruck;
    }
    public List<FoodTruck> HighestRating(Double min, Integer ret) {
        List<FoodTruck> foodTruck = foodTruckRepository.findFByDay(min, ret);
        if (foodTruck == null) {
            throw new ApiException("food Truck id Uncorecct");

        }
        return foodTruck;
    }

    public String currentStatus(Integer id) {
        FoodTruck foodTruck = foodTruckRepository.findFoodTruckById(id);
        if (foodTruck == null) {
            throw new ApiException("food truck id incorrect");

        }
        return "Current Status: " + foodTruck.getStatus();
    }
public void FoodTruckAcceptCheck(Integer food_id, Integer user_id) {
    FoodTruck food = foodTruckRepository.findFoodTruckById(food_id);
    // admin new
    User user = userRepository.findUsersById(user_id);

    if (food == null || user_id == null) {
        throw new ApiException("Food truck id or employee id incorrect");
    }
    if (food.getIsChecked().equals(true)){
        throw new ApiException("It has been verified before");
    }
    if (user.getRole().equals("ADMIN")) {
        food.setIsChecked(true);
        foodTruckRepository.save(food);
    } else throw new ApiException("the employee not admin");

}



    }