package com.example.foodtruck.Config;

import com.example.foodtruck.Service.MyUserDetailsService;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class Security {
    private final MyUserDetailsService myUserDetailsService;

    @Bean
    public DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider daoAuthenticationProvider=new DaoAuthenticationProvider();
        daoAuthenticationProvider.setUserDetailsService(myUserDetailsService);
        daoAuthenticationProvider.setPasswordEncoder(new BCryptPasswordEncoder());
        return daoAuthenticationProvider;
    }
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http)throws  Exception{
        http.csrf().disable()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.IF_REQUIRED)
                .and()
                .authenticationProvider(authenticationProvider())
                .authorizeHttpRequests()
                .requestMatchers("/api/v1/food/add","/api/v1/user/evaluation/{men}/{mix}","/api/v1/user/food/{number}","/api/v1/user/check","/api/v1/user/best/{number}/{re}","/api/v1/evaluation/get","/api/v1/evaluation/add").permitAll()
                .requestMatchers("/api/v1/user/add").permitAll()
                .requestMatchers("/api/v1/user/put/{id}","/api/v1/order/add","/api/v1/order/put/{id}","/api/v1/order/delete/{id}",
                        "/api/v1/order/getById/{id}","/api/v1/profile/add","/api/v1/profile/put/{id}","/api/v1/category/get","/api/v1/address/add",
                        "/api/v1/address/put{id}","/api/v1/service/get","/api/v1/service/getByFoodTruck/{name}","/api/v1/ticket/getById","/api/v1/order/add",
                        "/api/v1/order/put/{id}","/api/v1/order/delete/{id}","/api/v1/order/getById/{id}","/api/v1/evaluation/add","/api/v1/evaluation/update").hasAuthority("CUSTOMER")
                .requestMatchers("/api/v1/myuser/**").permitAll()
                .requestMatchers("/api/v1/food/put","/api/v1/food/endOrder/{id}","/api/v1/food/reject/{id}","/api/v1/food/accept/{id}",
                        "/api/v1/order/getByFoodTruckId/{id}","/api/v1/order/getByTotalPrice/{totalPrice}","/api/v1/order/getByDate/{start}/{end}","/api/v1/order/getByEqualDate/{date}","/api/v1/profile/get","/api/v1/profile/getById/{id}",
                        "/api/v1/category/add","/api/v1/category/put/{id}","/api/v1/address/get","/api/v1/address/getByCity/{city}","/api/v1/service/add","/api/v1/service/put/{id}","/api/v1/ticket/add","/api/v1/ticket/put/{Id}",
                        "/api/v1/ticket/delete/{id}","/api/v1/order/getByFoodTruckId/{id}","/api/v1/order/getByTotalPrice/{totalPrice}","/api/v1/order/getByDate/{start}/{end}","/api/v1/order/getByEqualDate/{date}",
                        "/api/v1/address/getByCity/{city}","/api/v1/address/getByCustomerId/{id}").hasAuthority("FOODTRUCK")

                .requestMatchers("/api/v1/food/add","/api/v1/food/get").permitAll()
                .requestMatchers("/api/v1/user/delete/{id}","/api/v1/profile/delete/{id}","/api/v1/address/delete/{id}").hasAnyAuthority("ADMIN","CUSTOMER")
                .requestMatchers("/api/v1/food/delete/{id}","/api/v1/category/delete/{id}","/api/v1/evaluation/findAllByFeedback/{c}","/api/v1/service/delete/{id}").hasAnyAuthority("ADMIN","FOODTRUCK")
                .requestMatchers("/api/v1/user/get","/api/v1/user/foodTruckAcceptCheck/{admin_id}/{food_id}","/api/v1/ticket/get","/api/v1/order/get").hasAuthority("ADMIN")
                .anyRequest().authenticated()
                .and()
                .logout().logoutUrl("/api/v1/user/logout")
                .deleteCookies("JSESSIONID")
                .invalidateHttpSession(true)
                .and()
                .httpBasic();
        return http.build();

    }
}
