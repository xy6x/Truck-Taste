package com.example.foodtruck.Controller;

import com.example.foodtruck.DTO.AddressDto;
import com.example.foodtruck.Model.Customer;
import com.example.foodtruck.Model.User;
import com.example.foodtruck.Service.AddressService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/address")
public class AddressController {
    private final AddressService addressService;
    //admin
    @GetMapping("/get")
    public ResponseEntity GetAllAddress(){
        return ResponseEntity.status(HttpStatus.OK).body(addressService.getAll());
    }
    @PostMapping("/add")
    public  ResponseEntity AddAddress(@AuthenticationPrincipal User auth,@RequestBody @Valid AddressDto addressDTO){
        addressService.addAddress(auth.getId(),addressDTO);
        return ResponseEntity.status(HttpStatus.OK).body("added Address");
    }
    @PutMapping("/put/{id}")
    public ResponseEntity UpdateAddress(@AuthenticationPrincipal Customer auth, @PathVariable Integer id, @RequestBody @Valid AddressDto addressDTO){
        addressService.updateAddress(auth.getId(),id,addressDTO);
        return ResponseEntity.status(HttpStatus.OK).body("update Address");
    }
    @DeleteMapping("/delete/{id}")
    public ResponseEntity deleteAddress(@AuthenticationPrincipal Customer auth,@PathVariable Integer id){
        addressService.deleteAddress(auth.getId(),id);
        return ResponseEntity.status(HttpStatus.OK).body("delete Address");
    }
    @GetMapping("/getByCity/{city}")
    public ResponseEntity getByCity(@PathVariable String city){
        return ResponseEntity.status(HttpStatus.OK).body(addressService.getByCity(city));
    }
    @GetMapping("/getByCustomerId/{id}")
    public ResponseEntity getByCustomerId(@PathVariable Integer id){
        return ResponseEntity.status(HttpStatus.OK).body(addressService.getByCustomerId(id));
    }
}
