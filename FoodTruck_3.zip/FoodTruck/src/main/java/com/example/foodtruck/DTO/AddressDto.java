package com.example.foodtruck.DTO;

import jakarta.persistence.Column;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AddressDto {
    private  String address;
    private String startDate;

        @NotEmpty(message = "City should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private String city;

    @NotEmpty(message = "City should not be empty")
    @Column(columnDefinition = "varchar(100) not null")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private String street;
    private Integer customer_id;
    private Integer profile_id;
}
