package com.example.foodtruck.DTO;

import com.example.foodtruck.Model.FoodTruck;
import com.example.foodtruck.Model.User;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.Column;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EvaluationDTO {
    //    @Column(columnDefinition = "varchar(225) ")
        @Pattern(regexp = "^[a-zA-Z ]+$")
    private String feedback;

    private Integer rating;


    private Integer customer_id;
    private Integer foodTruck_id;
    private Integer order_id;
}
