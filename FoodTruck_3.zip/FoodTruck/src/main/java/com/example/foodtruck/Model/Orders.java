package com.example.foodtruck.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "MyOrders")
public class Orders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(columnDefinition = "DATE")
    private LocalDate date;
    @NotNull(message = "number of day should not be empty")
    @Column(columnDefinition = "int not null")
    private Integer numberOfDay;
    private Float totalPrice;
    @Pattern(regexp = "^(Complete|Uncomplete)$",message = "status must be Complete or UnComplete")
    @Column(columnDefinition = "varchar(10) not null Check (orderStatus='Complete' or orderStatus='UnComplete')")
    private String orderStatus;
    @Column(columnDefinition = "varchar(50)")
    private String note;
    @Column(columnDefinition = "float")
    private Float discount;

    @ManyToOne
    @JoinColumn(name = "customer_id",referencedColumnName = "id")
    @JsonIgnore
    private Customer customer;



    @OneToOne(cascade = CascadeType.ALL,mappedBy = "order")
    @PrimaryKeyJoinColumn
    private Ticket ticket;

    @ManyToOne
    @JoinColumn(name = "foodTruck_id",referencedColumnName = "id")
    @JsonIgnore
    private FoodTruck foodTruck;
    @ManyToOne
    @JoinColumn(name = "address_id",referencedColumnName = "id")
    private Address address;

    @OneToMany(cascade = CascadeType.ALL,mappedBy = "orders")
    private Set<Evaluation> evaluations;
}
