package com.example.foodtruck.DTO;

import jakarta.persistence.Column;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class FoodTruckDTO {
    private Integer id;
    private  String userName;
    private String password;
    @Email(message = "Enter valid email")
    @NotEmpty(message = "Email should not be empty")
    private  String email;
        @NotEmpty(message = "phone should not be empty")
    @Pattern(regexp = "^05\\d{8}$", message = "Invalid phone number format")
    @Column(columnDefinition = "varchar(11) not null ")
    private String phone;
    private String role;
        @NotEmpty(message = "License should not be empty")
    private String License;
    @NotEmpty(message = "name should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    @Column(columnDefinition = "varchar(50) not null")
    private String name;

    @NotNull(message = "number of day should not be empty")
    @Column(columnDefinition = "int not null")
    private Integer NumberOfEmployee;
        @NotEmpty(message = "city should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    private String city;
    @Pattern(regexp = "^(Avaliable|tenant)$",message = "status must be Complete or UnComplete")
    private String status;
    private Double rating;
    private Integer Requests;
    @AssertFalse(message = "must be false")
    private Boolean isChecked;
}
