package com.example.foodtruck.Model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Getter
@Setter
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "MyAddres")
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @NotEmpty(message = "City should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    @Column(columnDefinition = "varchar(100) not null")
    private String city;
    @NotEmpty(message = "street should not be empty")
    @Pattern(regexp = "^[a-zA-Z ]+$")
    @Column(columnDefinition = "varchar(100) not null")
    private String street;


    @ManyToOne
    @JoinColumn(name = "profile_id",referencedColumnName = "id")
    @JsonIgnore
    private Profile profile;
    @OneToMany
    @JsonIgnore
    private Set<Orders> orders;
}
