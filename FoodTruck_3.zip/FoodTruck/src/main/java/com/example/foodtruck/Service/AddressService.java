package com.example.foodtruck.Service;

import com.example.foodtruck.ApiException.ApiException;
import com.example.foodtruck.DTO.AddressDto;
import com.example.foodtruck.Model.Address;
import com.example.foodtruck.Model.Customer;
import com.example.foodtruck.Model.Profile;
import com.example.foodtruck.Model.User;
import com.example.foodtruck.Repository.AddressRepository;
import com.example.foodtruck.Repository.CustomerRepository;
import com.example.foodtruck.Repository.ProfileRepository;
import com.example.foodtruck.Repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
@Service
public class AddressService {
    private final AddressRepository addressRepository;
    private final CustomerRepository customerRepository;
    private final ProfileRepository profileRepository;
    public List<Address> getAll(){

        return addressRepository.findAll();
    }
    public void addAddress(Integer id,AddressDto addressDTO){
        Customer customers=customerRepository.findCustomerById(id);
        if (customers == null) {
            throw new ApiException("the user not found");
        }
        Profile profile=profileRepository.findProfileById(addressDTO.getProfile_id());
        if (profile == null) {
            throw new ApiException("the id profile not found");
        }
        Customer customer =customerRepository.findCustomerById(profile.getCustomer().getId());
        if (customer == null) {
            throw new ApiException("the id user not found");
        }
        if (addressDTO.getCustomer_id()!=id) {
            throw new ApiException("the user not Authorized");
        }
        Address address =new Address(null,addressDTO.getCity(),addressDTO.getStreet(),profile,null);
        addressRepository.save(address);
    }
    public void updateAddress(Integer auth,Integer id , AddressDto addressDTO) {
        Address address=addressRepository.findAddressById(id);
        if (address == null) {
            throw new ApiException("the id address not found");
        } Customer customer = customerRepository.findCustomerById(auth);
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
        if (address.getProfile().getCustomer().getId()!=auth) {
            throw new ApiException("the user not Authorized");
        }


        address.setCity(addressDTO.getCity());
        address.setStreet(addressDTO.getStreet());
        addressRepository.save(address);
    }
    public void deleteAddress(Integer auth,Integer id){
        Address address = addressRepository.findAddressById(id);
        if (address == null) {
            throw new ApiException("the id nt found");
        }Customer customer = customerRepository.findCustomerById(auth);
        if (customer == null) {
            throw new ApiException("the id customer not found");
        }
        if (address.getProfile().getCustomer().getId()!=auth) {
            throw new ApiException("the user not Authorized");
        }
        addressRepository.delete(address);
    }
    public Address getByCity(String city){
        Address address=addressRepository.findAddressByCity(city);
        if(address==null){
            throw new ApiException("address not found");
        }
        return address;
    }
    public Set<Address> getByCustomerId(Integer id){
        Customer customer =customerRepository.findCustomerById(id);
        if(customer==null){
            throw new ApiException("user not found");
        }
        return customer.getProfile().getAddresses();
    }
}
